package me.lemire.lucene;

import java.io.File;
import java.util.Properties;
import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.benchmark.byTask.feeds.DocMaker;
import org.apache.lucene.benchmark.byTask.utils.Config;
import org.apache.lucene.document.*;
import org.apache.lucene.index.*;
import org.apache.lucene.store.FSDirectory;
import org.apache.lucene.search.*;
import org.json.JSONObject;
import org.json.JSONArray;
import java.io.FileInputStream;
import java.util.zip.GZIPInputStream;
import java.io.InputStreamReader;
import java.io.BufferedReader;
import java.util.HashMap;


/**
 * A simple utility to index wikipedia dumps using Lucene.
 *
 * @author Daniel Lemire
 *
 */
public class IndexDump {
    
	 public static HashMap<String, String> getAliases(){
			String inputFile = "/scratch/arahimi/cds/wiki/wiki_aliases.json.gz";
			HashMap<String, String> wikiAlias = new HashMap<String, String>();
			try {
			GZIPInputStream gzip = new GZIPInputStream(new FileInputStream(inputFile));
			BufferedReader br = new BufferedReader(new InputStreamReader(gzip));


			String content;
			//JSONParser jparser = new JSONParser();
			while ((content = br.readLine()) != null){
				JSONObject jo = new JSONObject(content);
				String url = jo.getString("url").replace("_", " ");
				JSONArray arr = jo.getJSONArray("aliases");
				String aliases = arr.toString().replace("\"", "").replace("[", "").replace("]", "").replace(",", " ");
				wikiAlias.put(url, aliases);
			}
			br.close();
			gzip.close();

			} catch(Exception e){
				System.out.println(e.getMessage());
			}
			return wikiAlias;
		}
        

        public static void main(String[] args) throws Exception {
                if (args.length <= 1) {
                        printUsage();
                        return;
                }
                File wikipediafile = new File(args[0]);
                if (!wikipediafile.exists()) {
                        System.out.println("Can't find "
                                + wikipediafile.getAbsolutePath());
                        return;
                }
                if (!wikipediafile.canRead()) {
                        System.out.println("Can't read "
                                + wikipediafile.getAbsolutePath());
                        return;
                }
                File outputDir = new File(args[1]);
                if (!outputDir.exists()) {
                        if (!outputDir.mkdirs()) {
                                System.out.println("couldn't create "
                                        + outputDir.getAbsolutePath());
                                return;
                        }
                }
                if (!outputDir.isDirectory()) {
                        System.out.println(outputDir.getAbsolutePath()
                                + " is not a directory!");
                        return;
                }
                if (!wikipediafile.canWrite()) {
                        System.out.println("Can't write to "
                                + outputDir.getAbsolutePath());
                        return;
                }

                HashMap<String, String> aliases = getAliases();
                System.out.println("Read aliases count = " + aliases.size());
                // we should be "ok" now

                FSDirectory dir = FSDirectory.open(outputDir.toPath());

                StandardAnalyzer analyzer = new StandardAnalyzer();
                IndexWriterConfig config = new IndexWriterConfig(analyzer);
                config.setOpenMode(IndexWriterConfig.OpenMode.CREATE);// overwrites
                                                                      // if
                                                                      // needed
                IndexWriter indexWriter = new IndexWriter(dir, config);

                DocMaker docMaker = new DocMaker();
                Properties properties = new Properties();
                properties.setProperty("content.source.forever", "false"); // will
                                                                           // parse
                                                                           // each
                                                                           // document
                                                                           // only
                                                                           // once
                properties.setProperty("docs.file",
                        wikipediafile.getAbsolutePath());
                properties.setProperty("keep.image.only.docs", "false");
                Config c = new Config(properties);
                EnwikiContentSource source = new EnwikiContentSource();
                source.setConfig(c);
                source.resetInputs();// though this does not seem needed, it is
                                     // (gets the file opened?)
                docMaker.setConfig(c, source);
                int count = 0;
                int bodycount = 0;
                System.out.println("Starting Indexing of Wikipedia dump "
                        + wikipediafile.getAbsolutePath());
                long start = System.currentTimeMillis();
                String[] badTitles = {"wikipedia:", "category:", "file:", "portal:", "template:", "mediawiki:", "user:", "help:", "book:", "draft:", "list of"};
                Document doc;
                try {
                        while ((doc = docMaker.makeDocument()) != null) {
                                Document mydoc = new Document();
                                if((doc.getField("docid"))!=null) {
                                  mydoc.add(new TextField("docid",
                                  doc.get("docid"),
                                   Field.Store.YES));
                                  bodycount++;
                                }
                                if((doc.getField("docname"))!=null) {
                                  mydoc.add(new TextField("name",
                                  doc.get("docname"),
                                   Field.Store.YES));
                                  bodycount++;
                                }
                                if(doc.getField("doctitle")!=null) {
                                  
                                  String title = doc.get("doctitle");
                                  boolean isBadTitle = false;
                                  for (String badt: badTitles) {
                                      if (title.toLowerCase().startsWith(badt)) {
                                          isBadTitle = true;
                                          continue;
                                      }
                                  }
                                  if (isBadTitle) {
                                      continue;
                                  }
                                  if (title.contains("disambiguation")){
                                      continue;
                                  }
                                  mydoc.add(new TextField("title",
                                  doc.get("doctitle"),
                                   Field.Store.YES));
                                  bodycount++;
                                  
                                  if (aliases.containsKey(title)){
                                      String names = aliases.get(title);
                                      mydoc.add(new TextField("aliases", names, Field.Store.YES));
                                      
                                  }
                                }
                                boolean hasBody = false;
                                if(doc.getField("body")!=null) {
                                  if(doc.get("body") != null) {
                                    hasBody = true;
                                    mydoc.add(new TextField("body",
                                    doc.get("body"),
                                    Field.Store.YES));
                                  bodycount++;
                                  }
                                }
                                if (hasBody){
                                    indexWriter.addDocument(mydoc);
                                }

                                ++count;

                                if (count % 1000 == 0)
                                        System.out
                                                .println("Indexed "
                                                        + count
                                                        + " documents ("+bodycount+" bodies) in "
                                                        + (System
                                                                .currentTimeMillis() - start)
                                                        + " ms");

                        }
                } catch (org.apache.lucene.benchmark.byTask.feeds.NoMoreDataException nmd) {
                        nmd.printStackTrace();
                }
                long finish = System.currentTimeMillis();
                System.out.println("Indexing " + count + " documents took "
                        + (finish - start) + " ms");
                System.out.println("Index should be located at "
                        + dir.getDirectory().toAbsolutePath());
                indexWriter.close();

                System.out.println("We are going to test the index by querying the word 'other' and getting the top 3 documents:");

                IndexReader reader = DirectoryReader.open(dir);
                IndexSearcher searcher = new IndexSearcher(reader);

                TermQuery query = new TermQuery(new Term("body", "other"));
                TopDocs hits = searcher.search(query, 3);
                for(ScoreDoc hit: hits.scoreDocs) {
                   Document document = searcher.doc(hit.doc);
                   System.out.println("Hit: ");
                   for(IndexableField iff : document.getFields()) {
                      String content = document.get(iff.name());
                      if(content.length() > 40) content = content.substring(0,40)+"...";
                      System.out.println(iff.name()+ " : " + content);
                   }
                }
        }


        private static void printUsage() {
                System.out
                        .println("Usage: java -cp <...> me.lemire.lucene.IndexDump somewikipediadump.xml.gz outputdir");
        }
}
