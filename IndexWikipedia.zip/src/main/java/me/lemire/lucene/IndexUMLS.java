package me.lemire.lucene;

import java.io.File;
import java.util.Properties;
import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.benchmark.byTask.feeds.DocMaker;
import org.apache.lucene.benchmark.byTask.utils.Config;
import org.apache.lucene.document.*;
import org.apache.lucene.index.*;
import org.apache.lucene.store.FSDirectory;
import org.apache.lucene.search.*;
import org.json.JSONObject;
import org.json.JSONArray;
import java.io.FileInputStream;
import java.util.zip.GZIPInputStream;
import java.io.InputStreamReader;
import java.io.BufferedReader;
import java.util.HashMap;
import java.io.IOException;

/**
 * A simple utility to index wikipedia dumps using Lucene.
 *
 * @author Daniel Lemire
 *
 */
public class IndexUMLS {
    
	 public static HashMap<String, String> getAliases(){
		        	
                StringBuilder sb = new StringBuilder();
                try {
                      GZIPInputStream gzip = new GZIPInputStream(new FileInputStream("/scratch/arahimi/cds/umls/mrconso.json.gz"));
                      BufferedReader br = new BufferedReader(new InputStreamReader(gzip));
                      String line;
                      while ((line = br.readLine()) != null) {
                          sb.append(line);
                      }
 
                      br.close();
                      gzip.close();
                  } catch(Exception e){
                      //System.out.println(queryStr);
                      e.printStackTrace();
                  }         
					
				
				String jString = sb.toString();
                JSONObject jo = new JSONObject(jString);
                HashMap<String, String> umlsAlias = new HashMap<String, String>();
                for (String cui: jo.keySet()){
                    JSONObject alias = jo.getJSONObject(cui).getJSONObject("alias");
                    if (!alias.has("ENG")){
                        continue;
                    }
                    JSONArray names = alias.getJSONArray("ENG");
                    String aliasStr = names.toString().replace("\"", "").replace("[", "").replace("]", "").replace(",", " ");
                    umlsAlias.put(cui, aliasStr);

                }

		return umlsAlias;
		}
        
       private static void addDoc(IndexWriter w, String docid, String title, String body, String aliases) throws IOException {
            /* Instead of lengthly process of adding each new entry, we can create a generic fuction to add 
                the new entry doc . We can add needed fields with field variable and respective tag .*/
            
            Document doc = new Document();
            doc.add(new TextField("title", title, Field.Store.YES));
            
            doc.add(new TextField("cui", docid, Field.Store.YES));
            doc.add(new TextField("aliases", aliases, Field.Store.YES));
            // use a string field for course_code because we don't want it tokenized
            doc.add(new StringField("body", body, Field.Store.YES));
            w.addDocument(doc);
        }

        public static void main(String[] args) throws Exception {
                File outputDir = new File(args[0]);
                if (!outputDir.exists()) {
                        if (!outputDir.mkdirs()) {
                                System.out.println("couldn't create "
                                        + outputDir.getAbsolutePath());
                                return;
                        }
                }
                if (!outputDir.isDirectory()) {
                        System.out.println(outputDir.getAbsolutePath()
                                + " is not a directory!");
                        return;
                }

                HashMap<String, String> aliases = getAliases();
                System.out.println("Read aliases count = " + aliases.size());
                // we should be "ok" now

                FSDirectory dir = FSDirectory.open(outputDir.toPath());

                StandardAnalyzer analyzer = new StandardAnalyzer();
                IndexWriterConfig config = new IndexWriterConfig(analyzer);
                config.setOpenMode(IndexWriterConfig.OpenMode.CREATE);// overwrites
                                                                      // if
                                                                      // needed
                IndexWriter indexWriter = new IndexWriter(dir, config);
                /*
                DocMaker docMaker = new DocMaker();
                Properties properties = new Properties();
                properties.setProperty("content.source.forever", "false"); // will
                                                                           // parse
                                                                           // each
                                                                           // document
                                                                           // only
                                                                           // once
                properties.setProperty("docs.file",
                        wikipediafile.getAbsolutePath());
                properties.setProperty("keep.image.only.docs", "false");
                Config c = new Config(properties);
                EnwikiContentSource source = new EnwikiContentSource();
                source.setConfig(c);
                source.resetInputs();// though this does not seem needed, it is
                                     // (gets the file opened?)
                docMaker.setConfig(c, source);
                */
                int count = 0;
                int bodycount = 0;
                System.out.println("Starting Indexing ...");
                long start = System.currentTimeMillis();
                
                /*
                try {
                        while ((doc = docMaker.makeDocument()) != null) {
                                Document mydoc = new Document();
                                if((doc.getField("docid"))!=null) {
                                  mydoc.add(new TextField("docid",
                                  doc.get("docid"),
                                   Field.Store.YES));
                                  bodycount++;
                                }
                                if((doc.getField("docname"))!=null) {
                                  mydoc.add(new TextField("name",
                                  doc.get("docname"),
                                   Field.Store.YES));
                                  bodycount++;
                                }
                                if(doc.getField("doctitle")!=null) {
                                  
                                  String title = doc.get("doctitle");
                                  if (title.contains("disambiguation") || title.contains("Category") || title.contains(":")){
                                      continue;
                                  }
                                  mydoc.add(new TextField("title",
                                  doc.get("doctitle"),
                                   Field.Store.YES));
                                  bodycount++;
                                  
                                  if (aliases.containsKey(title)){
                                      String names = aliases.get(title);
                                      mydoc.add(new TextField("aliases", names, Field.Store.YES));
                                      
                                  }
                                }

                                if(doc.getField("body")!=null) {
                                  if(doc.get("body") != null) {
                                    mydoc.add(new TextField("body",
                                    doc.get("body"),
                                    Field.Store.YES));
                                  bodycount++;
                                  }
                                }
                                indexWriter.addDocument(mydoc);

                                ++count;

                                if (count % 1000 == 0)
                                        System.out
                                                .println("Indexed "
                                                        + count
                                                        + " documents ("+bodycount+" bodies) in "
                                                        + (System
                                                                .currentTimeMillis() - start)
                                                        + " ms");

                        }
                */
                try {
                      FileInputStream f = new FileInputStream("/scratch/arahimi/cds/umls/umlsdocs.json");
                      BufferedReader br = new BufferedReader(new InputStreamReader(f));
                      String line;
                      while ((line = br.readLine()) != null) { 
                        JSONObject jo = new JSONObject(line);
                        String cui = jo.get("document_id").toString();
                        String title = jo.get("title").toString();
                        String text = jo.get("text").toString();
                        String aliasesStr = aliases.get(cui);
                        try{ 
                            addDoc(indexWriter, cui, title, text, aliasesStr);
                        } catch(Exception e){e.printStackTrace();}
                        ++count;
                        if (count % 1000 == 0)
                                System.out
                                        .println("Indexed "
                                                + count
                                                + " documents ("+bodycount+" bodies) in "
                                                + (System
                                                        .currentTimeMillis() - start)
                                                + " ms");


                      }
 
                      br.close();
                      f.close();
                  } catch(Exception e){
                      //System.out.println(queryStr);
                      e.printStackTrace();
                  }         
	
                long finish = System.currentTimeMillis();
                System.out.println("Indexing " + count + " documents took "
                        + (finish - start) + " ms");
                System.out.println("Index should be located at "
                        + dir.getDirectory().toAbsolutePath());
                indexWriter.close();

                System.out.println("We are going to test the index by querying the word 'other' and getting the top 3 documents:");

                IndexReader reader = DirectoryReader.open(dir);
                IndexSearcher searcher = new IndexSearcher(reader);

                TermQuery query = new TermQuery(new Term("body", "family"));
                TopDocs hits = searcher.search(query, 3);
                for(ScoreDoc hit: hits.scoreDocs) {
                   Document document = searcher.doc(hit.doc);
                   System.out.println("Hit: ");
                   for(IndexableField iff : document.getFields()) {
                      String content = document.get(iff.name());
                      if(content.length() > 40) content = content.substring(0,40)+"...";
                      System.out.println(iff.name()+ " : " + content);
                   }
                }
        }


        private static void printUsage() {
                System.out
                        .println("Usage: java -cp <...> me.lemire.lucene.IndexDump somewikipediadump.xml.gz outputdir");
        }
}
