package me.lemire.lucene;

import java.io.File;
import java.util.Properties;
import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.benchmark.byTask.feeds.DocMaker;
import org.apache.lucene.benchmark.byTask.utils.Config;
import org.apache.lucene.document.*;
import org.apache.lucene.index.*;
import org.apache.lucene.store.FSDirectory;
import org.apache.lucene.search.*;
import java.io.FileReader; 
import java.util.Iterator; 
import java.util.Map; 
import org.apache.lucene.queryparser.classic.QueryParser;
import java.util.ArrayList;
import org.json.JSONObject;
import org.json.JSONArray;
import java.io.FileInputStream;
import java.util.zip.GZIPInputStream;
import java.io.InputStreamReader;
import java.io.BufferedReader;
import java.util.HashMap;
import java.io.*;

/**
 * A simple utility to index wikipedia dumps using Lucene.
 *
 * @author Daniel Lemire
 *
 */
public class QueryWikiWiki {

        public static void main(String[] args) throws Exception {
                if (args.length <= 2) {
                        printUsage();
                        //return;
                }
                
                File outputDir = new File("Index");
                if (!outputDir.exists()) {
                        System.out.println("couldn't find "
                                        + outputDir.getAbsolutePath());
                        //return;
                }
                if (!outputDir.isDirectory()) {
                        System.out.println(outputDir.getAbsolutePath()
                                + " is not a directory!");
                        //return;
                }
                if (!outputDir.canRead()) {
                        System.out.println("Can't read to "
                                + outputDir.getAbsolutePath());
                        //return;
                }

                // we should be "ok" now

                FSDirectory dir = FSDirectory.open(outputDir.toPath());
                IndexReader reader = DirectoryReader.open(dir);
                StandardAnalyzer analyzer = new StandardAnalyzer();
                QueryParser parser = new QueryParser("title", analyzer);
                //System.out.println(reader.toString());
                IndexSearcher searcher = new IndexSearcher(reader);
                //System.out.println("Yes!, we are inside.");
                //TermQuery query = new TermQuery(new Term("body", "cool"));
                String queryStr = "";
                ArrayList <String> queries = new ArrayList<String>();
                try {
                     FileInputStream gzip = new FileInputStream("/scratch/arahimi/cds/wiki/all_.txt");
                     BufferedReader br = new BufferedReader(new InputStreamReader(gzip));
                     String line;
                     while ((line = br.readLine()) != null) {
                         queries.add(line.trim());
                     }
                     
                     br.close();
                     gzip.close();
                 } catch(Exception e){
                     //System.out.println(queryStr);
                     e.printStackTrace();
                 }
                
                     ArrayList<String> topk = new ArrayList<String>();
                     StringBuilder sbResults = new StringBuilder();
                     int errors = 0;
                     for (String q: queries){
                        sbResults.setLength(0);
                        String[] q_id = q.split("\t");
                        String cui = q_id[0];
                        String nameW = QueryParser.escape(q_id[1]);

                        sbResults.append(cui + "\t");
                        queryStr = "(title:(" + nameW + ")^1.5 OR aliases:(" + nameW + ")^1.5 OR body:(" + nameW + "))";    
                        TopDocs hits = null;
                        try{
                            hits = searcher.search(parser.parse(queryStr), 64);
                        } catch (Exception e){
                            errors++;
                            e.printStackTrace();
                            System.out.println(queryStr);
                            System.out.println("errors: " + errors);
                            continue;
                        }
                       
                        for(ScoreDoc hit: hits.scoreDocs) {                                                                                                                                               
                             Document document = searcher.doc(hit.doc);                                                                                                                                    
                             IndexableField k = document.getField("title");                                                                                                                                
                             IndexableField name = document.getField("name");                                                                                                                              
                             //IndexableField id = document.getField("cui");                                                                                                                               
                             //System.out.println(document.get(k.name()));                                                                                                                                 
                             //sbResults.append(document.get(id.name()) + "||" + document.get(k.name()) + "|||");                                                                                          
                             sbResults.append(document.get(name.name())  + "|||");                                                                                                                         
                         }
                        
                        String allResults = sbResults.toString();
                        if (allResults.length() > 10){
                            allResults = allResults.substring(0, allResults.length() - 3);
                        }
                        System.out.println(allResults);

                     }
         
 

     }


        private static void printUsage() {
                System.out
                        .println("Usage: java -cp <...> me.lemire.lucene.Query Index term, yesss");
        }
}
